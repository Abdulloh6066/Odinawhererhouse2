import React, { useState } from 'react';
import { CreditCard, Package, DollarSign, Calendar, User, CheckCircle, XCircle, Plus, Minus, Search, Filter, X, Trash2, Save } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Product, Category, DebtPayment } from '../types';

export default function DebtPage() {
  const [products, setProducts] = useLocalStorage<Product[]>('warehouse-products', []);
  const [categories] = useLocalStorage<Category[]>('warehouse-categories', []);
  const [debtPayments, setDebtPayments] = useLocalStorage<DebtPayment[]>('debt-payments', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'unpaid' | 'paid'>('all');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [showQuickPayment, setShowQuickPayment] = useState(false);
  const [quickPaymentText, setQuickPaymentText] = useState('');

  // Calculate debt for each product
  const getProductDebt = (product: Product) => {
    const totalCost = product.price * product.quantity;
    const totalPaid = debtPayments
      .filter(payment => payment.productId === product.id)
      .reduce((sum, payment) => sum + payment.amount, 0);
    return Math.max(0, totalCost - totalPaid);
  };

  // Check if product is fully paid
  const isProductPaid = (product: Product) => {
    return getProductDebt(product) === 0;
  };

  // Filter products based on search and filters
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (product.supplierName && product.supplierName.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === '' || product.category === selectedCategory;
    
    const matchesStatus = filterStatus === 'all' || 
                         (filterStatus === 'paid' && isProductPaid(product)) ||
                         (filterStatus === 'unpaid' && !isProductPaid(product));
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Calculate totals
  const getTotalDebt = () => {
    return filteredProducts.reduce((total, product) => total + getProductDebt(product), 0);
  };

  const getAllProductsDebt = () => {
    return products.reduce((total, product) => total + getProductDebt(product), 0);
  };

  const getTotalPaid = () => {
    return debtPayments.reduce((total, payment) => total + payment.amount, 0);
  };

  const getUnpaidProductsCount = () => {
    return products.filter(product => !isProductPaid(product)).length;
  };

  // Get unique supplier names for suggestions
  const getUniqueSuppliers = () => {
    const suppliers = new Set(
      products
        .filter(p => p.supplierName && p.supplierName.trim())
        .map(p => p.supplierName!.trim())
    );
    return Array.from(suppliers).sort();
  };

  // Enhanced payment processing with expense deduction
  const handleQuickPayment = () => {
    const text = quickPaymentText.trim();
    if (!text) {
      alert('Iltimos, to\'lov ma\'lumotini kiriting');
      return;
    }

    // Check if it's an expense deduction (starts with -)
    const isExpenseDeduction = text.startsWith('-');
    
    if (isExpenseDeduction) {
      // Handle expense deduction: "-harajat 50000 Go'ja"
      const expenseMatch = text.match(/^-\s*(.+?)\s+(\d+)\s+(.+)$/);
      if (!expenseMatch) {
        alert('Noto\'g\'ri format!\nHarajat uchun: "-harajat 50000 Go\'ja" yoki "-xarid 100000 Mahmud O\'ga"');
        return;
      }

      const expenseType = expenseMatch[1].trim();
      const expenseAmount = parseFloat(expenseMatch[2]);
      const supplierName = expenseMatch[3].trim();

      if (expenseAmount <= 0) {
        alert('Harajat miqdori 0 dan katta bo\'lishi kerak');
        return;
      }

      console.log('Expense deduction:', { expenseType, expenseAmount, supplierName });

      // Find products from this supplier that have debt
      const supplierProducts = products.filter(product => {
        if (!product.supplierName) return false;
        
        const productSupplier = product.supplierName.toLowerCase().trim();
        const searchSupplier = supplierName.toLowerCase().trim();
        
        const matches = productSupplier.includes(searchSupplier) || searchSupplier.includes(productSupplier);
        const hasDebt = getProductDebt(product) > 0;
        
        return matches && hasDebt;
      });

      if (supplierProducts.length === 0) {
        const availableSuppliers = getUniqueSuppliers();
        let message = `"${supplierName}" ta'minotchisidan qarzda mahsulot topilmadi.`;
        
        if (availableSuppliers.length > 0) {
          message += `\n\nMavjud ta'minotchilar:\n${availableSuppliers.join(', ')}`;
        }
        
        alert(message);
        return;
      }

      // Sort by debt amount (highest first)
      supplierProducts.sort((a, b) => getProductDebt(b) - getProductDebt(a));

      let remainingDeduction = expenseAmount;
      const deductionsToMake: { productId: string; amount: number; productName: string }[] = [];

      // Distribute deduction across products
      for (const product of supplierProducts) {
        if (remainingDeduction <= 0) break;
        
        const productDebt = getProductDebt(product);
        const deductionForThisProduct = Math.min(remainingDeduction, productDebt);
        
        deductionsToMake.push({
          productId: product.id,
          amount: deductionForThisProduct,
          productName: product.name
        });
        
        remainingDeduction -= deductionForThisProduct;
      }

      if (deductionsToMake.length === 0) {
        alert('Harajat uchun qarz topilmadi');
        return;
      }

      // Create payment records (deductions are recorded as payments)
      const now = new Date();
      const uzbekTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Tashkent"}));

      const newPayments: DebtPayment[] = deductionsToMake.map((deduction, index) => ({
        id: (Date.now() + index).toString(),
        productId: deduction.productId,
        amount: deduction.amount,
        paymentDate: uzbekTime.toISOString(),
        notes: `${expenseType} harajati - ${supplierName} dan ${formatPrice(expenseAmount)} chegirma (${deduction.productName})`
      }));

      setDebtPayments([...newPayments, ...debtPayments]);
      setQuickPaymentText('');
      setShowQuickPayment(false);

      const totalDeducted = deductionsToMake.reduce((sum, d) => sum + d.amount, 0);
      
      let message = `✅ Harajat muvaffaqiyatli chegirma qilindi!\n\n`;
      message += `💸 ${formatPrice(totalDeducted)} "${expenseType}" harajati ${deductionsToMake.length} ta mahsulotdan chegirma qilindi:\n\n`;
      
      deductionsToMake.forEach((deduction, index) => {
        message += `${index + 1}. ${deduction.productName}: ${formatPrice(deduction.amount)}\n`;
      });
      
      if (remainingDeduction > 0) {
        message += `\n⚠️ Ogohlantirish: ${formatPrice(remainingDeduction)} ortiqcha harajat qoldi (barcha qarzlar to'langan)`;
      }
      
      alert(message);
      return;
    }

    // Regular payment processing (existing code)
    // "Mahmud O'ga 500000-" or "Mahmud O'ga 500000" or "Goja 1000000-"
    const match = text.match(/^(.+?)\s+(\d+)\s*-?\s*$/);
    if (!match) {
      alert('Noto\'g\'ri format!\n\nTo\'lov uchun: "Mahmud O\'ga 500000-" yoki "Goja 1000000"\nHarajat uchun: "-harajat 50000 Go\'ja"');
      return;
    }

    const supplierName = match[1].trim();
    const paymentAmount = parseFloat(match[2]);

    if (paymentAmount <= 0) {
      alert('To\'lov miqdori 0 dan katta bo\'lishi kerak');
      return;
    }

    console.log('Looking for supplier:', supplierName);
    console.log('Payment amount:', paymentAmount);

    // Find products from this supplier that have debt
    const supplierProducts = products.filter(product => {
      if (!product.supplierName) return false;
      
      const productSupplier = product.supplierName.toLowerCase().trim();
      const searchSupplier = supplierName.toLowerCase().trim();
      
      // Check if supplier names match (exact or partial)
      const matches = productSupplier.includes(searchSupplier) || searchSupplier.includes(productSupplier);
      const hasDebt = getProductDebt(product) > 0;
      
      console.log(`Product: ${product.name}, Supplier: "${product.supplierName}", Matches: ${matches}, Has Debt: ${hasDebt}, Debt: ${getProductDebt(product)}`);
      
      return matches && hasDebt;
    });

    console.log('Found supplier products:', supplierProducts.length);

    if (supplierProducts.length === 0) {
      const availableSuppliers = getUniqueSuppliers();
      let message = `"${supplierName}" ta'minotchisidan qarzda mahsulot topilmadi.`;
      
      if (availableSuppliers.length > 0) {
        message += `\n\nMavjud ta'minotchilar:\n${availableSuppliers.join(', ')}`;
      } else {
        message += '\n\nHech qanday ta\'minotchi nomi ko\'rsatilmagan mahsulotlar mavjud.';
      }
      
      alert(message);
      return;
    }

    // Sort by debt amount (highest first) to pay off expensive items first
    supplierProducts.sort((a, b) => getProductDebt(b) - getProductDebt(a));

    let remainingPayment = paymentAmount;
    const paymentsToMake: { productId: string; amount: number; productName: string }[] = [];

    // Distribute payment across products
    for (const product of supplierProducts) {
      if (remainingPayment <= 0) break;
      
      const productDebt = getProductDebt(product);
      const paymentForThisProduct = Math.min(remainingPayment, productDebt);
      
      paymentsToMake.push({
        productId: product.id,
        amount: paymentForThisProduct,
        productName: product.name
      });
      
      remainingPayment -= paymentForThisProduct;
    }

    if (paymentsToMake.length === 0) {
      alert('To\'lov qilish uchun qarz topilmadi');
      return;
    }

    // Create payment records
    const now = new Date();
    const uzbekTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Tashkent"}));

    const newPayments: DebtPayment[] = paymentsToMake.map((payment, index) => ({
      id: (Date.now() + index).toString(),
      productId: payment.productId,
      amount: payment.amount,
      paymentDate: uzbekTime.toISOString(),
      notes: `${supplierName} ga to'lov - ${formatPrice(paymentAmount)} dan ${formatPrice(payment.amount)} (${payment.productName})`
    }));

    setDebtPayments([...newPayments, ...debtPayments]);
    setQuickPaymentText('');
    setShowQuickPayment(false);

    const totalApplied = paymentsToMake.reduce((sum, p) => sum + p.amount, 0);
    
    let message = `✅ Muvaffaqiyatli!\n\n`;
    message += `💰 ${formatPrice(totalApplied)} to'lov ${paymentsToMake.length} ta mahsulotga taqsimlandi:\n\n`;
    
    paymentsToMake.forEach((payment, index) => {
      message += `${index + 1}. ${payment.productName}: ${formatPrice(payment.amount)}\n`;
    });
    
    if (remainingPayment > 0) {
      message += `\n⚠️ Ogohlantirish: ${formatPrice(remainingPayment)} ortiqcha to'lov qoldi (barcha qarzlar to'langan)`;
    }
    
    alert(message);
  };

  const handleDeletePayment = (paymentId: string) => {
    if (window.confirm('Ushbu to\'lovni o\'chirishga ishonchingiz komilmi?')) {
      setDebtPayments(debtPayments.filter(p => p.id !== paymentId));
    }
  };

  const getCategoryName = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.name : 'Kategoriyasiz';
  };

  const getCategoryColor = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category ? category.color : 'bg-gray-500';
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('uz-UZ', {
      timeZone: 'Asia/Tashkent',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory('');
    setFilterStatus('all');
  };

  return (
    <div className="space-y-6 pb-20 lg:pb-0">
      {/* Beautiful Header */}
      <div className="bg-gradient-to-r from-red-50 to-pink-50 rounded-xl shadow-lg p-6 border border-red-200">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-red-600 to-pink-600 p-3 rounded-xl">
              <CreditCard className="h-7 w-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">Mahsulot Qarzlari</h1>
              <p className="text-slate-600">Sotib olingan mahsulotlar uchun qarzlarni kuzatib boring</p>
            </div>
          </div>
          
          {/* Quick Payment Button */}
          <button
            onClick={() => setShowQuickPayment(true)}
            className="flex items-center space-x-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-2 rounded-lg hover:from-green-700 hover:to-green-800 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <DollarSign className="h-5 w-5" />
            <span className="hidden sm:inline">Tez To'lov</span>
            <span className="sm:hidden">To'lov</span>
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Total Debt */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Jami Qarz</p>
                <p className="text-2xl font-bold text-red-600">{formatPrice(getAllProductsDebt())}</p>
                <p className="text-xs text-slate-500">Barcha mahsulotlar</p>
              </div>
              <div className="bg-red-100 p-3 rounded-full">
                <CreditCard className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </div>

          {/* Filtered Debt */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Ko'rsatilgan Qarz</p>
                <p className="text-2xl font-bold text-orange-600">{formatPrice(getTotalDebt())}</p>
                <p className="text-xs text-slate-500">
                  {filteredProducts.length === products.length ? 'Barcha' : 'Filtrlangan'}
                </p>
              </div>
              <div className="bg-orange-100 p-3 rounded-full">
                <Package className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>

          {/* Total Paid */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Jami To'langan</p>
                <p className="text-2xl font-bold text-green-600">{formatPrice(getTotalPaid())}</p>
                <p className="text-xs text-slate-500">Barcha to'lovlar</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          {/* Unpaid Products */}
          <div className="bg-white rounded-lg p-4 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">To'lanmagan</p>
                <p className="text-2xl font-bold text-purple-600">{getUnpaidProductsCount()}</p>
                <p className="text-xs text-slate-500">Mahsulotlar soni</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-full">
                <XCircle className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Payment Form */}
      {showQuickPayment && (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <div className="bg-green-100 p-2 rounded-full">
                  <DollarSign className="h-5 w-5 text-green-600" />
                </div>
                Tez To'lov va Harajat Chegirmasi
              </h2>
              <button
                onClick={() => {
                  setShowQuickPayment(false);
                  setQuickPaymentText('');
                }}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors duration-200"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  To'lov yoki Harajat Ma'lumoti
                </label>
                <input
                  type="text"
                  placeholder="To'lov: 'Mahmud O'ga 500000' | Harajat: '-benzin 50000 Go'ja'"
                  value={quickPaymentText}
                  onChange={(e) => setQuickPaymentText(e.target.value)}
                  list="suppliers"
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 text-base"
                />
                <datalist id="suppliers">
                  {getUniqueSuppliers().map(supplier => (
                    <option key={supplier} value={`${supplier} `} />
                  ))}
                </datalist>
                
                {/* Enhanced Instructions */}
                <div className="mt-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-xs font-medium text-blue-800 mb-2">Format:</p>
                  <div className="space-y-1 text-xs text-blue-700">
                    <div className="flex items-center space-x-2">
                      <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded">To'lov:</span>
                      <span>"Ta'minotchi nomi + miqdor" (masalan: "Mahmud O'ga 500000")</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="bg-red-100 text-red-800 px-2 py-0.5 rounded">Harajat:</span>
                      <span>"-harajat turi + miqdor + ta'minotchi" (masalan: "-benzin 50000 Go'ja")</span>
                    </div>
                  </div>
                </div>
                
                {/* Show available suppliers */}
                {getUniqueSuppliers().length > 0 && (
                  <div className="mt-2 p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <p className="text-xs font-medium text-slate-700 mb-1">Mavjud ta'minotchilar:</p>
                    <div className="flex flex-wrap gap-1">
                      {getUniqueSuppliers().map(supplier => (
                        <button
                          key={supplier}
                          type="button"
                          onClick={() => setQuickPaymentText(`${supplier} `)}
                          className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded hover:bg-slate-200 transition-colors duration-200"
                        >
                          {supplier}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setShowQuickPayment(false);
                    setQuickPaymentText('');
                  }}
                  className="flex items-center justify-center space-x-2 px-4 py-2 text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors duration-200 border border-slate-300"
                >
                  <X className="h-4 w-4" />
                  <span>Bekor Qilish</span>
                </button>
                <button
                  onClick={handleQuickPayment}
                  className="flex items-center justify-center space-x-2 bg-gradient-to-r from-green-600 to-green-700 text-white px-4 py-2 rounded-lg hover:from-green-700 hover:to-green-800 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Save className="h-4 w-4" />
                  <span>Bajarish</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-slate-200">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-5 w-5 text-slate-600" />
          <h2 className="text-lg font-semibold text-slate-800">Filtrlar</h2>
          {(searchTerm || selectedCategory || filterStatus !== 'all') && (
            <button
              onClick={clearFilters}
              className="ml-auto text-sm text-red-600 hover:text-red-700 font-medium"
            >
              Barcha Filtrlarni Tozalash
            </button>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Search */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Qidirish</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Mahsulot nomi, tavsif yoki ta'minotchi..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200 text-sm"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Kategoriya</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200 bg-white text-sm"
            >
              <option value="">Barcha Kategoriyalar</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Holat</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as 'all' | 'unpaid' | 'paid')}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200 bg-white text-sm"
            >
              <option value="all">Barchasi</option>
              <option value="unpaid">To'lanmagan</option>
              <option value="paid">To'langan</option>
            </select>
          </div>
        </div>
      </div>

      {/* Excel-style Table */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white rounded-xl shadow-lg p-8 text-center border border-slate-200">
          <Package className="h-16 w-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-600 mb-2">
            {products.length === 0 
              ? "Mahsulotlar yo'q" 
              : "Filtr bo'yicha mahsulot topilmadi"
            }
          </h3>
          <p className="text-slate-500 mb-4">
            {products.length === 0 
              ? "Avval mahsulot qo'shing, keyin qarzlarni kuzatib boring."
              : "Filtr mezonlarini o'zgartirib ko'ring."
            }
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gradient-to-r from-slate-50 to-slate-100 border-b-2 border-slate-300">
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">№</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">Mahsulot</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">Ta'minotchi</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 border-r border-slate-300">Kategoriya</th>
                  <th className="px-4 py-3 text-right font-semibold text-slate-700 border-r border-slate-300">Jami Qarz</th>
                  <th className="px-4 py-3 text-right font-semibold text-slate-700 border-r border-slate-300">To'langan</th>
                  <th className="px-4 py-3 text-right font-semibold text-slate-700 border-r border-slate-300">Qolgan</th>
                  <th className="px-4 py-3 text-center font-semibold text-slate-700 border-r border-slate-300">Holat</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">Sana</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((product, index) => {
                  const totalCost = product.price * product.quantity;
                  const remainingDebt = getProductDebt(product);
                  const totalPaid = totalCost - remainingDebt;
                  const isPaid = remainingDebt === 0;
                  
                  return (
                    <tr key={product.id} className={`border-b border-slate-200 hover:bg-slate-50 transition-colors duration-150 ${
                      isPaid ? 'bg-green-50' : 'bg-red-50'
                    }`}>
                      <td className="px-4 py-3 border-r border-slate-200 text-slate-600 font-medium">
                        {index + 1}
                      </td>
                      <td className="px-4 py-3 border-r border-slate-200">
                        <div>
                          <div className="font-semibold text-slate-800">{product.name}</div>
                          <div className="text-xs text-slate-600 truncate max-w-xs" title={product.description}>
                            {product.description}
                          </div>
                          <div className="text-xs text-slate-500">
                            {product.quantity} {product.unit} × {formatPrice(product.price)}
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 border-r border-slate-200 text-slate-600">
                        {product.supplierName ? (
                          <div className="flex items-center space-x-1">
                            <User className="h-3 w-3" />
                            <span className="truncate">{product.supplierName}</span>
                          </div>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                      <td className="px-4 py-3 border-r border-slate-200">
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${getCategoryColor(product.category)}`}></div>
                          <span className="text-slate-600 text-xs">{getCategoryName(product.category)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 border-r border-slate-200 text-right font-bold text-slate-800">
                        {formatPrice(totalCost)}
                      </td>
                      <td className="px-4 py-3 border-r border-slate-200 text-right font-semibold text-green-600">
                        {formatPrice(totalPaid)}
                      </td>
                      <td className="px-4 py-3 border-r border-slate-200 text-right font-bold">
                        <span className={isPaid ? 'text-green-600' : 'text-red-600'}>
                          {formatPrice(remainingDebt)}
                        </span>
                      </td>
                      <td className="px-4 py-3 border-r border-slate-200 text-center">
                        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          isPaid 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {isPaid ? (
                            <>
                              <CheckCircle className="h-3 w-3 mr-1" />
                              To'langan
                            </>
                          ) : (
                            <>
                              <XCircle className="h-3 w-3 mr-1" />
                              Qarzda
                            </>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-600 text-xs">
                        {formatDate(product.dateAdded)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-gradient-to-r from-slate-100 to-slate-200 border-t-2 border-slate-400">
                  <td colSpan="4" className="px-4 py-4 text-right font-bold text-slate-800 border-r border-slate-300 text-base">
                    JAMI:
                  </td>
                  <td className="px-4 py-4 text-right font-bold text-slate-800 border-r border-slate-300 text-base">
                    {formatPrice(filteredProducts.reduce((sum, p) => sum + (p.price * p.quantity), 0))}
                  </td>
                  <td className="px-4 py-4 text-right font-bold text-green-700 border-r border-slate-300 text-base">
                    {formatPrice(filteredProducts.reduce((sum, p) => sum + ((p.price * p.quantity) - getProductDebt(p)), 0))}
                  </td>
                  <td className="px-4 py-4 text-right font-bold text-red-700 border-r border-slate-300 text-lg">
                    {formatPrice(getTotalDebt())}
                  </td>
                  <td colSpan="2" className="px-4 py-4 text-center text-sm text-slate-600">
                    {filteredProducts.length} mahsulot ko'rsatilgan
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}