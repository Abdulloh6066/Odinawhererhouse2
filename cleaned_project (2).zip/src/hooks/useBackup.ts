import { useState } from 'react';
import { useLocalStorage } from './useLocalStorage';
import { Product, Category, DebtPayment } from '../types';

interface CashTransaction {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  description: string;
  category: string;
  date: string;
  notes?: string;
  supplierName?: string;
}

interface BackupData {
  products: Product[];
  categories: Category[];
  debtPayments: DebtPayment[];
  cashTransactions: CashTransaction[];
  backupDate: string;
  version: string;
}

export function useBackup() {
  const [products] = useLocalStorage<Product[]>('warehouse-products', []);
  const [categories] = useLocalStorage<Category[]>('warehouse-categories', []);
  const [debtPayments] = useLocalStorage<DebtPayment[]>('debt-payments', []);
  const [cashTransactions] = useLocalStorage<CashTransaction[]>('cash-transactions', []);
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  // Create backup data
  const createBackup = (): BackupData => {
    const now = new Date();
    const uzbekTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Tashkent"}));
    
    return {
      products,
      categories,
      debtPayments,
      cashTransactions,
      backupDate: uzbekTime.toISOString(),
      version: '1.0'
    };
  };

  // Export data to file
  const exportData = async () => {
    try {
      setIsExporting(true);
      const backupData = createBackup();
      
      const dataStr = JSON.stringify(backupData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      
      const now = new Date();
      const uzbekTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Tashkent"}));
      const dateStr = uzbekTime.toISOString().split('T')[0];
      const timeStr = uzbekTime.toTimeString().split(' ')[0].replace(/:/g, '-');
      
      link.download = `ombor-backup-${dateStr}-${timeStr}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      return true;
    } catch (error) {
      console.error('Export error:', error);
      return false;
    } finally {
      setIsExporting(false);
    }
  };

  // Import data from file
  const importData = async (file: File): Promise<{ success: boolean; message: string }> => {
    try {
      setIsImporting(true);
      
      const text = await file.text();
      const backupData: BackupData = JSON.parse(text);
      
      // Validate backup data structure
      if (!backupData.products || !backupData.categories || !backupData.debtPayments || !backupData.cashTransactions) {
        return { success: false, message: 'Noto\'g\'ri backup fayl formati' };
      }
      
      // Store current data as emergency backup
      const emergencyBackup = createBackup();
      localStorage.setItem('emergency-backup', JSON.stringify(emergencyBackup));
      
      // Import new data
      localStorage.setItem('warehouse-products', JSON.stringify(backupData.products));
      localStorage.setItem('warehouse-categories', JSON.stringify(backupData.categories));
      localStorage.setItem('debt-payments', JSON.stringify(backupData.debtPayments));
      localStorage.setItem('cash-transactions', JSON.stringify(backupData.cashTransactions));
      
      // Reload page to reflect changes
      window.location.reload();
      
      return { success: true, message: 'Ma\'lumotlar muvaffaqiyatli yuklandi' };
    } catch (error) {
      console.error('Import error:', error);
      return { success: false, message: 'Backup faylni yuklashda xatolik yuz berdi' };
    } finally {
      setIsImporting(false);
    }
  };

  // Auto backup to localStorage with timestamp
  const createAutoBackup = () => {
    try {
      const backupData = createBackup();
      const autoBackups = JSON.parse(localStorage.getItem('auto-backups') || '[]');
      
      // Keep only last 5 auto backups
      autoBackups.unshift(backupData);
      if (autoBackups.length > 5) {
        autoBackups.splice(5);
      }
      
      localStorage.setItem('auto-backups', JSON.stringify(autoBackups));
      localStorage.setItem('last-auto-backup', new Date().toISOString());
      
      return true;
    } catch (error) {
      console.error('Auto backup error:', error);
      return false;
    }
  };

  // Get auto backups
  const getAutoBackups = (): BackupData[] => {
    try {
      return JSON.parse(localStorage.getItem('auto-backups') || '[]');
    } catch {
      return [];
    }
  };

  // Restore from auto backup
  const restoreFromAutoBackup = (backupIndex: number): boolean => {
    try {
      const autoBackups = getAutoBackups();
      if (backupIndex >= 0 && backupIndex < autoBackups.length) {
        const backupData = autoBackups[backupIndex];
        
        // Store current data as emergency backup
        const emergencyBackup = createBackup();
        localStorage.setItem('emergency-backup', JSON.stringify(emergencyBackup));
        
        // Restore data
        localStorage.setItem('warehouse-products', JSON.stringify(backupData.products));
        localStorage.setItem('warehouse-categories', JSON.stringify(backupData.categories));
        localStorage.setItem('debt-payments', JSON.stringify(backupData.debtPayments));
        localStorage.setItem('cash-transactions', JSON.stringify(backupData.cashTransactions));
        
        // Reload page
        window.location.reload();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Restore error:', error);
      return false;
    }
  };

  // Get backup statistics
  const getBackupStats = () => {
    const lastAutoBackup = localStorage.getItem('last-auto-backup');
    const autoBackups = getAutoBackups();
    const emergencyBackup = localStorage.getItem('emergency-backup');
    
    return {
      totalProducts: products.length,
      totalCategories: categories.length,
      totalDebtPayments: debtPayments.length,
      totalCashTransactions: cashTransactions.length,
      lastAutoBackup: lastAutoBackup ? new Date(lastAutoBackup) : null,
      autoBackupsCount: autoBackups.length,
      hasEmergencyBackup: !!emergencyBackup
    };
  };

  return {
    exportData,
    importData,
    createAutoBackup,
    getAutoBackups,
    restoreFromAutoBackup,
    getBackupStats,
    isExporting,
    isImporting
  };
}