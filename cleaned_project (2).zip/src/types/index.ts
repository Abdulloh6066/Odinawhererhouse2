export interface Product {
  id: string;
  name: string;
  description: string;
  quantity: number;
  unit: 'kg' | 'dona'; // kg = kilogram, dona = piece in Uzbek
  price: number;
  category: string;
  dateAdded: string;
  notes?: string;
  isPaidFor?: boolean; // Track if this product debt is paid
  supplierName?: string; // Who we owe money to
}

export interface Category {
  id: string;
  name: string;
  description: string;
  color: string;
  createdAt: string;
}

export interface DebtPayment {
  id: string;
  productId: string;
  amount: number;
  paymentDate: string;
  notes?: string;
}